/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for split view controller for iOS.
*/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AAPLSplitViewController : UISplitViewController

@end

NS_ASSUME_NONNULL_END
